-- =============================================================
-- AI-ChatBot — Schema SQL
-- PostgreSQL 14+
-- =============================================================

-- agents
CREATE TABLE agents (
    agent_id          VARCHAR(64)   PRIMARY KEY,
    name              VARCHAR(255)  NOT NULL,
    owner             VARCHAR(64)   NOT NULL,
    api_key_hash      VARCHAR(64)   NOT NULL UNIQUE,
    ai_model          VARCHAR(64),
    ai_api_key        TEXT,
    ai_validated      BOOLEAN       NOT NULL DEFAULT FALSE,
    created_at        TIMESTAMP     NOT NULL,
    updated_at        TIMESTAMP     NOT NULL,
    active_since      TIMESTAMP,
    last_activity_at  TIMESTAMP,
    deleted_at        TIMESTAMP
);

-- agent_contexts (one row per version; current = MAX(version))
CREATE TABLE agent_contexts (
    id          SERIAL        PRIMARY KEY,
    agent_id    VARCHAR(64)   NOT NULL REFERENCES agents(agent_id) ON DELETE CASCADE,
    version     INTEGER       NOT NULL DEFAULT 1,
    context     JSONB         NOT NULL DEFAULT '{}',
    changes     JSONB         NOT NULL DEFAULT '[]',
    updated_at  TIMESTAMP     NOT NULL,
    UNIQUE (agent_id, version)
);

-- user_contexts (one row per user+agent)
CREATE TABLE user_contexts (
    id           SERIAL        PRIMARY KEY,
    user_id      VARCHAR(64)   NOT NULL,
    agent_id     VARCHAR(64)   NOT NULL REFERENCES agents(agent_id) ON DELETE CASCADE,
    created_at   TIMESTAMP     NOT NULL,
    updated_at   TIMESTAMP     NOT NULL,
    segment      VARCHAR(128),
    language     VARCHAR(16),
    form_answers JSONB,
    UNIQUE (user_id, agent_id)
);

-- sessions
CREATE TABLE sessions (
    session_id      VARCHAR(64)   PRIMARY KEY,
    agent_id        VARCHAR(64)   NOT NULL REFERENCES agents(agent_id) ON DELETE CASCADE,
    user_id         VARCHAR(64),
    model           VARCHAR(64)   NOT NULL,
    started_at      TIMESTAMP     NOT NULL,
    ended_at        TIMESTAMP,
    total_messages  INTEGER       NOT NULL DEFAULT 0,
    input_tokens    INTEGER       NOT NULL DEFAULT 0,
    output_tokens   INTEGER       NOT NULL DEFAULT 0,
    total_tokens    INTEGER       NOT NULL DEFAULT 0,
    resolved        BOOLEAN       NOT NULL DEFAULT FALSE,
    escalated       BOOLEAN       NOT NULL DEFAULT FALSE,
    deleted_at      TIMESTAMP
);

-- session_history (persisted on session end)
CREATE TABLE session_history (
    session_id  VARCHAR(64)  PRIMARY KEY REFERENCES sessions(session_id) ON DELETE CASCADE,
    agent_id    VARCHAR(64)  NOT NULL,
    messages    JSONB        NOT NULL DEFAULT '[]'
);

-- scores (NLP scores aggregated per session)
CREATE TABLE scores (
    session_id               VARCHAR(64)   PRIMARY KEY REFERENCES sessions(session_id) ON DELETE CASCADE,
    agent_id                 VARCHAR(64)   NOT NULL,
    messages                 JSONB         NOT NULL DEFAULT '[]',
    avg_sentiment_score      FLOAT,
    sentiment_label          VARCHAR(16)   CHECK (sentiment_label IN ('positive', 'neutral', 'negative')),
    all_topics               JSONB,
    main_topic               VARCHAR(255),
    intent                   VARCHAR(128),
    avg_user_message_length  FLOAT,
    avg_response_time_ms     FLOAT,
    updated_at               TIMESTAMP     NOT NULL
);

-- insights (AI-generated, on demand)
CREATE TABLE insights (
    session_id        VARCHAR(64)   PRIMARY KEY REFERENCES sessions(session_id) ON DELETE CASCADE,
    agent_id          VARCHAR(64)   NOT NULL,
    generated_at      TIMESTAMP     NOT NULL,
    key_points        JSONB,
    suggested_actions JSONB,
    summary           TEXT
);

-- knowledge_files (uploaded knowledge base files per agent)
CREATE TABLE knowledge_files (
    file_id     VARCHAR(64)   PRIMARY KEY,
    agent_id    VARCHAR(64)   NOT NULL REFERENCES agents(agent_id) ON DELETE CASCADE,
    filename    VARCHAR(255)  NOT NULL,
    file_type   VARCHAR(16)   NOT NULL CHECK (file_type IN ('csv', 'json', 'pdf', 'excel', 'txt', 'docx', 'url')),
    records     JSONB         NOT NULL DEFAULT '[]',
    uploaded_at TIMESTAMP     NOT NULL,
    updated_at  TIMESTAMP     NOT NULL
);

-- Indexes
CREATE INDEX idx_agent_contexts_agent_id   ON agent_contexts(agent_id);
CREATE INDEX idx_user_contexts_agent_id    ON user_contexts(agent_id);
CREATE INDEX idx_user_contexts_user_id     ON user_contexts(user_id);
CREATE INDEX idx_sessions_agent_id         ON sessions(agent_id);
CREATE INDEX idx_sessions_user_id          ON sessions(user_id);
CREATE INDEX idx_sessions_deleted_at       ON sessions(deleted_at);
CREATE INDEX idx_session_history_agent_id  ON session_history(agent_id);
CREATE INDEX idx_scores_agent_id           ON scores(agent_id);
CREATE INDEX idx_insights_agent_id         ON insights(agent_id);
CREATE INDEX idx_knowledge_files_agent_id  ON knowledge_files(agent_id);
CREATE INDEX idx_agents_deleted_at         ON agents(deleted_at);
